class Autor:
    def __init__(self,id:int,nome:str,email:str,telefone:str, biografia:str) -> None:
        self.__id = id
        self.__nome = nome
        self.__email = email
        self.__telefone = telefone
        self.__biografia = biografia

    @property
    def id(self) -> int:
        return self.__id
    
    @id.setter
    def id(self, id: int) -> None:
        self.__id = id
    
    @property
    def nome(self) -> str:
        return self.__nome
    
    @nome.setter
    def nome(self, nome: str) -> None:
        self.__nome = nome

    @property
    def email(self) -> str:
        return self.__email
    
    @email.setter
    def email(self, email: str) -> None:
        self.__email = email
    @property
    def telefone(self) -> str:
        return self.__telefone
    
    @telefone.setter
    def telefone(self, telefone: str) -> None:
        self.__telefone = telefone
    @property
    def biografia(self) -> str:
        return self.__biografia
    
    @biografia.setter
    def biografia(self, biografia: biografia) -> None:
        self.__biografia = biografia
    
