import itertools

class Categoria:
    def __init__(self, id: int, nome: str) -> None:
        self.__id: int = id
        self.__nome: str = nome

    @property
    def id(self) -> int:
        return self.__id

    @id.setter
    def id(self, id: int) -> None:
        self.__id = id

    @property
    def nome(self) -> str:
        return self.__nome

    @nome.setter
    def nome(self, nome: str) -> None:
        self.__nome = nome

    def __repr__(self):
        return f'Categoria(id={self.__id}, nome="{self.__nome}")'
