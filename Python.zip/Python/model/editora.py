class Editora:
    def __init__(self,id:int,nome:str,endereco:str,telefone:str) -> None:
        self.__id = id
        self.__nome = nome
        self._endereco= endereco
        self.__telefone = telefone

    @property
    def id(self) ->int:
        return self.__id
    
    @id.setter
    def id(self, id: int) -> None:
        self.__id = id

    @property
    def nome(self) ->str:
        return self.__nome
    
    @nome.setter
    def nome(self, nome: str) -> None:
        self.__nome = nome

    @property
    def telefone(self) ->str:
        return self.__telefone
    
    @telefone.setter
    def telefone(self, telefone: str) -> None:
        self.__telefone = telefone