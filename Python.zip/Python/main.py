from service.categoria_service import CategoriaService

if __name__ == '__main__':
    service = CategoriaService()
    service.menu()
