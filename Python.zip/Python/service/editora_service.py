from dao.editora_dao import EditoraDAO
from model.editora import Editora

class CategoriaService:
    def __init__(self) -> None:
        self.__editora_dao: EditoraDAO = EditoraDAO()

    def menu(self):
        print('[Categoria] Escolha entre as opções a seguir:\n'
              '1 - Listar editoras cadastradas\n'
              '2 - Adicionar nova editora\n'
              '3 - Excluir editora existente\n'
              '4 - Procurar editora por ID\n'
              '0 - Voltar ao menu inicial')

        escolha = input('Escolha uma opção: ')
        match escolha:
            case '0':
                return
            case '1':
                self.listar()
            case '2':
                self.adicionar()
            case '3':
                self.remover()
            case '4':
                self.buscar_por_id()
            case _:
                print('Opção inválida!')

    def listar(self):
        print('Editoras cadastradas:\n')
        editoras = self.__editora_dao.listar()
        if not editoras:
            print("Não existem editoras cadastradas!")

        for editora in editoras:
            print(editora)

        input('Pressione uma tecla para continuar')

    def adicionar(self):
        nome = input('Digite o nome da editora que deseja adicionar: ')
        nova_editora = Editora(0, nome)  # O ID será definido automaticamente no DAO
        self.__editora_dao.adicionar(nova_editora)
        print("Categoria adicionada com sucesso!")
        self.menu()  # Volta ao menu após adicionar

    def remover(self):
        editora_id = int(input('Digite o ID da editora a ser removida: '))
        if self.__editora_dao.remover(editora_id):
            print("Editora removida com sucesso!")
            self.menu()
        else:
            print("Editora não encontrada!")
        input('Pressione uma tecla para continuar')
        self.menu()

    def buscar_por_id(self):
        editora_id = int(input('Digite o ID da categoria a ser procurada: '))
        editora = self.__editora_dao.buscar_por_id(editora_id)
        if editora:
            print(editora)
            self.menu()
        else:
            print("Categoria não encontrada!")
        input('Pressione uma tecla para continuar')
        self.menu()

if __name__ == '__main__':
    service = CategoriaService()
    service.menu()
