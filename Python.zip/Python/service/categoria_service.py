from dao.categoria_dao import CategoriaDAO
from model.categoria import Categoria

class CategoriaService:
    def __init__(self) -> None:
        self.__categoria_dao: CategoriaDAO = CategoriaDAO()

    def menu(self):
        print('[Categoria] Escolha entre as opções a seguir:\n'
              '1 - Listar categorias cadastradas\n'
              '2 - Adicionar nova categoria\n'
              '3 - Excluir categoria existente\n'
              '4 - Procurar categoria por ID\n'
              '0 - Voltar ao menu inicial')

        escolha = input('Escolha uma opção: ')
        match escolha:
            case '0':
                return
            case '1':
                self.listar()
            case '2':
                self.adicionar()
            case '3':
                self.remover()
            case '4':
                self.buscar_por_id()
            case _:
                print('Opção inválida!')

    def listar(self):
        print('Categorias cadastradas:\n')
        categorias = self.__categoria_dao.listar()
        if not categorias:
            print("Não existem categorias cadastradas! Retorne ao menu inicial e preencha uma nova categoria!")

        for categoria in categorias:
            print(categoria)

        input('Pressione uma tecla para continuar')

    def adicionar(self):
        nome = input('Digite o nome da categoria que deseja adicionar: ')
        nova_categoria = Categoria(0, nome)  # O ID será definido automaticamente no DAO
        self.__categoria_dao.adicionar(nova_categoria)
        print("Categoria adicionada com sucesso!")
        self.menu()  # Volta ao menu após adicionar

    def remover(self):
        categoria_id = int(input('Digite o ID da categoria a ser removida: '))
        if self.__categoria_dao.remover(categoria_id):
            print("Categoria removida com sucesso!")
            self.menu()
        else:
            print("Categoria não encontrada!")
        input('Pressione uma tecla para continuar')
        self.menu()

    def buscar_por_id(self):
        categoria_id = int(input('Digite o ID da categoria a ser procurada: '))
        categoria = self.__categoria_dao.buscar_por_id(categoria_id)
        if categoria:
            print(categoria)
            self.menu()
        else:
            print("Categoria não encontrada!")
        input('Pressione uma tecla para continuar')
        self.menu()

if __name__ == '__main__':
    service = CategoriaService()
    service.menu()
