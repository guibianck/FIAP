import itertools
from model.autor import Autor

class AutorDAO:
    def __init__(self) -> None:
        self.__autores: list[Autor] = []  # Banco de Dados
        self.__id_generator = itertools.count(start=1)  # Cria um gerador de IDs começando de 1

    def listar(self) -> list[Autor]:  # SELECT TABLE
        return self.__autores
    
    def adicionar(self, autor: Autor) -> None:  # INSERT TABLE
        autor.id = next(self.__id_generator)  # Atribui um novo ID
        self.__autores.append(autor)
          
    def remover(self, autor_id: int) -> bool:
        for cat in self.__autores:
            if cat.id == autor_id:
                self.__autores.remove(cat)
                return True
        return False

    def buscar_por_id(self, autor_id: int) -> Autor:
        for c in self.__autores:
            if c.id == autor_id:
                return c
        return None
