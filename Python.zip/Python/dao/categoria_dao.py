import itertools
from model.categoria import Categoria

import itertools
from model.categoria import Categoria

class CategoriaDAO:
    def __init__(self) -> None:
        self.__categorias: list[Categoria] = []  # Banco de Dados
        self.__id_generator = itertools.count(start=1)  # Cria um gerador de IDs começando de 1

    def listar(self) -> list[Categoria]:  # SELECT TABLE
        return self.__categorias
    
    def adicionar(self, categoria: Categoria) -> None:  # INSERT TABLE
        categoria.id = next(self.__id_generator)  # Atribui um novo ID
        self.__categorias.append(categoria)
          
    def remover(self, categoria_id: int) -> bool:
        for cat in self.__categorias:
            if cat.id == categoria_id:
                self.__categorias.remove(cat)
                return True
        return False

    def buscar_por_id(self, categoria_id: int) -> Categoria:
        for c in self.__categorias:
            if c.id == categoria_id:
                return c
        return None
