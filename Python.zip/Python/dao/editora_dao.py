import itertools
from model.editora import Editora

class EditoraDAO:
    def __init__(self) -> None:
        self.__editoras: list[Editora] = []  # Banco de Dados
        self.__id_generator = itertools.count(start=1)  # Cria um gerador de IDs começando de 1

    def listar(self) -> list[Editora]:  # SELECT TABLE
        return self.__editoras
    
    def adicionar(self, editora: Editora) -> None:  # INSERT TABLE
        editora.id = next(self.__id_generator)  # Atribui um novo ID
        self.__editoras.append(editora)
          
    def remover(self, editora_id: int) -> bool:
        for cat in self.__editoras:
            if cat.id == editora_id:
                self.__editoras.remove(cat)
                return True
        return False

    def buscar_por_id(self, editora_id: int) -> Editora:
        for c in self.__editoras:
            if c.id == editora_id:
                return c
        return None
